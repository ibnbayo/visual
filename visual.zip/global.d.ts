declare module 'tailwindcss/tailwind' {
  export interface TailwindConfig {
    // add custom Tailwind types here
  }
}
