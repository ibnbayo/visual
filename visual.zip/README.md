# Data Visualization

[![Screenshot-2023-07-24-at-06-47-50.png](https://i.postimg.cc/kMSfRQfr/Screenshot-2023-07-24-at-06-47-50.png)](https://postimg.cc/NLg1Wr3b)

## Getting Started

First, run:

```bash
npm run dev-server
```
then
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result. 
