describe('Example Test', ()=> {
    it('should navigate to example page', ()=> {
        cy.visit("/example")
    })
})